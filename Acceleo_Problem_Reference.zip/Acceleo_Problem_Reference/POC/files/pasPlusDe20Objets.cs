using System;
using System.Collections.ObjectModel;
using EA;

namespace GuidelinesVerification
{
    class pasPlusDe20Objets : IDiragramRuleVerification
    {
		// Attributes
		public static string = "Il y a plus de 10 objets dans ce diagramme"
		
		// Main Method
		public bool CheckDiagram(EA.Diagram Diagram_inst){
			bool result = Diagram_inst.DiagramObjects
			************ OPERATION **************
			operation undefined ? : false
			operation.name undefined ? :true
			operation.name : 
			************ OPERATION **************
			()
			************ OPERATION **************
			operation undefined ? : false
			operation.name undefined ? :true
			operation.name : 
			************ OPERATION **************
			(20)
			return result;
		}
    }
}
