using System;
using System.Collections.ObjectModel;
using EA;

namespace GuidelinesVerification
{
    class nomNonNull : IDiragramRuleVerification
    {
		// Attributes
		public static string = "Le nom du diagramme doit faire plus de 1 char"
		
		// Main Method
		public bool CheckDiagram(EA.Diagram Diagram_inst){
			bool result = Diagram_inst.Name
			************ OPERATION **************
			operation undefined ? : false
			operation.name undefined ? :true
			operation.name : 
			************ OPERATION **************
			("")
			return result;
		}
    }
}
