using System;
using System.Collections.ObjectModel;
using EA;

namespace GuidelinesVerification
{
    class nbObj : IDiragramRuleVerification
    {
		// Attributes
		public static string = "nombre_objet"
		
		// Main Method
		public bool CheckDiagram(EA.Diagram Diagram_inst){
			bool result = Diagram_inst
			************ OPERATION **************
			operation undefined ? : false
			operation.name undefined ? :false
			operation.name : nombreObj3
			************ OPERATION **************
			()
			************ OPERATION **************
			operation undefined ? : false
			operation.name undefined ? :true
			operation.name : 
			************ OPERATION **************
			(2)
			return result;
		}
    }
}
