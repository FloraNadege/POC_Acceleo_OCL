/**
 */
package pOC.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import pOC.Diagram;
import pOC.DiagramLink;
import pOC.DiagramObject;
import pOC.POCPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Diagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link pOC.impl.DiagramImpl#getDiagramLinks <em>Diagram Links</em>}</li>
 *   <li>{@link pOC.impl.DiagramImpl#getDiagramObjects <em>Diagram Objects</em>}</li>
 *   <li>{@link pOC.impl.DiagramImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DiagramImpl extends MinimalEObjectImpl.Container implements Diagram {
	/**
	 * The cached value of the '{@link #getDiagramLinks() <em>Diagram Links</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiagramLinks()
	 * @generated
	 * @ordered
	 */
	protected EList<DiagramLink> diagramLinks;

	/**
	 * The cached value of the '{@link #getDiagramObjects() <em>Diagram Objects</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiagramObjects()
	 * @generated
	 * @ordered
	 */
	protected EList<DiagramObject> diagramObjects;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DiagramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return POCPackage.Literals.DIAGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DiagramLink> getDiagramLinks() {
		if (diagramLinks == null) {
			diagramLinks = new EObjectContainmentEList<DiagramLink>(DiagramLink.class, this,
					POCPackage.DIAGRAM__DIAGRAM_LINKS);
		}
		return diagramLinks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DiagramObject> getDiagramObjects() {
		if (diagramObjects == null) {
			diagramObjects = new EObjectContainmentEList<DiagramObject>(DiagramObject.class, this,
					POCPackage.DIAGRAM__DIAGRAM_OBJECTS);
		}
		return diagramObjects;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POCPackage.DIAGRAM__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case POCPackage.DIAGRAM__DIAGRAM_LINKS:
			return ((InternalEList<?>) getDiagramLinks()).basicRemove(otherEnd, msgs);
		case POCPackage.DIAGRAM__DIAGRAM_OBJECTS:
			return ((InternalEList<?>) getDiagramObjects()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case POCPackage.DIAGRAM__DIAGRAM_LINKS:
			return getDiagramLinks();
		case POCPackage.DIAGRAM__DIAGRAM_OBJECTS:
			return getDiagramObjects();
		case POCPackage.DIAGRAM__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case POCPackage.DIAGRAM__DIAGRAM_LINKS:
			getDiagramLinks().clear();
			getDiagramLinks().addAll((Collection<? extends DiagramLink>) newValue);
			return;
		case POCPackage.DIAGRAM__DIAGRAM_OBJECTS:
			getDiagramObjects().clear();
			getDiagramObjects().addAll((Collection<? extends DiagramObject>) newValue);
			return;
		case POCPackage.DIAGRAM__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case POCPackage.DIAGRAM__DIAGRAM_LINKS:
			getDiagramLinks().clear();
			return;
		case POCPackage.DIAGRAM__DIAGRAM_OBJECTS:
			getDiagramObjects().clear();
			return;
		case POCPackage.DIAGRAM__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case POCPackage.DIAGRAM__DIAGRAM_LINKS:
			return diagramLinks != null && !diagramLinks.isEmpty();
		case POCPackage.DIAGRAM__DIAGRAM_OBJECTS:
			return diagramObjects != null && !diagramObjects.isEmpty();
		case POCPackage.DIAGRAM__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //DiagramImpl
