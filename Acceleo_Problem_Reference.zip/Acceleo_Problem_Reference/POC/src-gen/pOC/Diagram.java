/**
 */
package pOC;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diagram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link pOC.Diagram#getDiagramLinks <em>Diagram Links</em>}</li>
 *   <li>{@link pOC.Diagram#getDiagramObjects <em>Diagram Objects</em>}</li>
 *   <li>{@link pOC.Diagram#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see pOC.POCPackage#getDiagram()
 * @model
 * @generated
 */
public interface Diagram extends EObject {
	/**
	 * Returns the value of the '<em><b>Diagram Links</b></em>' containment reference list.
	 * The list contents are of type {@link pOC.DiagramLink}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Diagram Links</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Diagram Links</em>' containment reference list.
	 * @see pOC.POCPackage#getDiagram_DiagramLinks()
	 * @model containment="true"
	 * @generated
	 */
	EList<DiagramLink> getDiagramLinks();

	/**
	 * Returns the value of the '<em><b>Diagram Objects</b></em>' containment reference list.
	 * The list contents are of type {@link pOC.DiagramObject}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Diagram Objects</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Diagram Objects</em>' containment reference list.
	 * @see pOC.POCPackage#getDiagram_DiagramObjects()
	 * @model containment="true"
	 * @generated
	 */
	EList<DiagramObject> getDiagramObjects();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see pOC.POCPackage#getDiagram_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link pOC.Diagram#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Diagram
