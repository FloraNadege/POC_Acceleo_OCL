/**
 */
package pOC;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diagram Link</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pOC.POCPackage#getDiagramLink()
 * @model
 * @generated
 */
public interface DiagramLink extends EObject {
} // DiagramLink
