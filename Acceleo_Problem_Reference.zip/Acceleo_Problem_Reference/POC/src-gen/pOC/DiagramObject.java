/**
 */
package pOC;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diagram Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pOC.POCPackage#getDiagramObject()
 * @model
 * @generated
 */
public interface DiagramObject extends EObject {
} // DiagramObject
